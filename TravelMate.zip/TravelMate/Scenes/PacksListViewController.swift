import UIKit

class PacksListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    private var packs: [Offer] = []

    private let tableView: UITableView = {
        let tv = UITableView()
        tv.register(PackCell.self, forCellReuseIdentifier: PackCell.identifier)
        tv.showsVerticalScrollIndicator = false
        tv.separatorStyle = .none
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.backgroundColor = UIColor(white: 0.96, alpha: 1)
        return tv
    }()
    
    private let refresh = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Packs Voyages"
        view.backgroundColor = UIColor(white: 0.95, alpha: 1)

        setupTable()
        fetchPacks()
    }

    // MARK: - Setup
    private func setupTable() {
        view.addSubview(tableView)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        refresh.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        tableView.refreshControl = refresh
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    @objc private func refreshData() {
        fetchPacks()
    }

    // MARK: - Fetch packs
    private func fetchPacks() {
        Task {
            do {
                let result = try await PackService.shared.getAllPacks()
                
                // If backend empty → fallback to mock
                self.packs = result.isEmpty ? [Offer.mock] : result
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    self.refresh.endRefreshing()
                }
                
            } catch {
                print("❌ Failed to fetch packs: \(error)")
                DispatchQueue.main.async {
                    self.packs = [Offer.mock]  // fallback
                    self.tableView.reloadData()
                    self.refresh.endRefreshing()
                }
            }
        }
    }

    // MARK: - Table View Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return packs.count
    }

    func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {

        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: PackCell.identifier,
            for: indexPath
        ) as? PackCell else {
            return UITableViewCell()
        }

        let pack = packs[indexPath.row]
        cell.configure(with: pack)

        // Chat button inside the cell
        cell.onChatTapped = { [weak self] in
            let chatVC = ChatViewController(offer: pack)
            self?.navigationController?.pushViewController(chatVC, animated: true)
        }

        return cell
    }

    // MARK: - Select row → Details
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let pack = packs[indexPath.row]
        let detailsVC = PackDetailViewController(offer: pack)
        navigationController?.pushViewController(detailsVC, animated: true)
    }

    // MARK: - Row height
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 260
    }
}
