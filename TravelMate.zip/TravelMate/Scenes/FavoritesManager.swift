import Foundation

class FavoritesManager {
    static let shared = FavoritesManager()
    private let key = "favorite_packs"

    private init() {}

    func addFavorite(_ offer: Offer) {
        var favs = getFavorites()
        if !favs.contains(where: { $0.id == offer.id }) {
            favs.append(offer)
        }
        save(favs)
    }

    func removeFavorite(id: String) {
        var favs = getFavorites()
        favs.removeAll { $0.id == id }
        save(favs)
    }

    func isFavorite(id: String) -> Bool {
        return getFavorites().contains(where: { $0.id == id })
    }

    func getFavorites() -> [Offer] {
        if let data = UserDefaults.standard.data(forKey: key) {
            return (try? JSONDecoder().decode([Offer].self, from: data)) ?? []
        }
        return []
    }

    private func save(_ list: [Offer]) {
        if let data = try? JSONEncoder().encode(list) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
