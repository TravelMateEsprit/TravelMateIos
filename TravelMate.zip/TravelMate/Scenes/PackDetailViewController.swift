import UIKit

class PackDetailViewController: UIViewController {

    private let offer: Offer
    
    // MARK: - Booking quantities
    private var adults: Int = 1
    private var childrenCount: Int = 0
    
    private var totalPrice: Double {
        return Double(adults) * offer.baseAdultPrice
             + Double(childrenCount) * offer.baseChildPrice
    }

    // MARK: - Favorite
    private var isFavorite: Bool {
        get { FavoritesManager.shared.isFavorite(id: offer.id ?? "") }
        set {
            if newValue { FavoritesManager.shared.addFavorite(offer) }
            else { FavoritesManager.shared.removeFavorite(id: offer.id ?? "") }
            updateFavoriteIcon()
        }
    }

    // MARK: UI
    private let imageView = UIImageView()
    private let titleLabel = UILabel()
    private let infoCard = UIStackView()
    private let detailCard = UIStackView()
    private let travelerCard = UIStackView()
    private let totalCard = UIStackView()
    
    private let hotelLabel = UILabel()
    private let nightsLabel = UILabel()
    private let mealLabel = UILabel()
    private let dateLabel = UILabel()
    private let transportLabel = UILabel()
    private let activitiesLabel = UILabel()
    private let placesLabel = UILabel()
    private let totalPriceLabel = UILabel()

    // Buttons
    private let chatButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("💬 Discuter avec l'agence", for: .normal)
        b.titleLabel?.font = .boldSystemFont(ofSize: 16)
        b.backgroundColor = .systemBlue
        b.setTitleColor(.white, for: .normal)
        b.layer.cornerRadius = 12
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()
    
    private let reserveButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("🛒 Réserver maintenant", for: .normal)
        b.titleLabel?.font = .boldSystemFont(ofSize: 16)
        b.backgroundColor = .systemGreen
        b.setTitleColor(.white, for: .normal)
        b.layer.cornerRadius = 12
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()
    
    // Traveler pickers
    private let adultsLabel = UILabel()
    private let childrenLabel = UILabel()
    private let adultsStepper = UIStepper()
    private let childrenStepper = UIStepper()

    init(offer: Offer) {
        self.offer = offer
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.96, alpha: 1)

        title = "Détails du Pack"
        setupFavoriteButton()
        setupUI()
        fillData()
    }

    // MARK: - Favorite Star
    private func setupFavoriteButton() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: isFavorite ? "star.fill" : "star"),
            style: .plain,
            target: self,
            action: #selector(toggleFavorite)
        )
        navigationItem.rightBarButtonItem?.tintColor = .systemYellow
    }

    @objc private func toggleFavorite() {
        isFavorite.toggle()
        updateFavoriteIcon()
    }

    private func updateFavoriteIcon() {
        navigationItem.rightBarButtonItem?.image =
            UIImage(systemName: isFavorite ? "star.fill" : "star")
    }

    // MARK: UI Setup
    private func setupUI() {
        
        // Scroll container
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        let content = UIStackView()
        content.axis = .vertical
        content.spacing = 20
        content.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(content)

        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            content.topAnchor.constraint(equalTo: scroll.topAnchor),
            content.leadingAnchor.constraint(equalTo: scroll.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: scroll.trailingAnchor),
            content.widthAnchor.constraint(equalTo: scroll.widthAnchor),
            content.bottomAnchor.constraint(equalTo: scroll.bottomAnchor)
        ])
        
        // HEADER IMAGE
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.heightAnchor.constraint(equalToConstant: 260).isActive = true
        
        // TITLE
        titleLabel.font = .boldSystemFont(ofSize: 26)
        titleLabel.numberOfLines = 0
        
        // CARDS
        styleCard(infoCard)
        styleCard(detailCard)
        styleCard(travelerCard)
        styleCard(totalCard)

        content.addArrangedSubview(imageView)
        content.addArrangedSubview(padded(titleLabel))
        
        // HOTEL INFO CARD
        infoCard.addArrangedSubview(line(hotelLabel))
        infoCard.addArrangedSubview(line(nightsLabel))
        infoCard.addArrangedSubview(line(mealLabel))
        infoCard.addArrangedSubview(line(dateLabel))
        content.addArrangedSubview(infoCard)

        // TRANSPORT + ACTIVITIES + PLACES
        detailCard.addArrangedSubview(sectionTitle("✈️ Transport"))
        detailCard.addArrangedSubview(line(transportLabel))
        
        detailCard.addArrangedSubview(sectionTitle("🎟 Activités incluses"))
        detailCard.addArrangedSubview(line(activitiesLabel))
        
        detailCard.addArrangedSubview(sectionTitle("🗺 Lieux à visiter"))
        detailCard.addArrangedSubview(line(placesLabel))
        
        content.addArrangedSubview(detailCard)
        
        // TRAVELERS SECTION
        buildTravelerSection()
        content.addArrangedSubview(travelerCard)
        
        // TOTAL CARD
        totalPriceLabel.font = .boldSystemFont(ofSize: 22)
        totalPriceLabel.textColor = .systemGreen
        totalCard.addArrangedSubview(line(totalPriceLabel))
        content.addArrangedSubview(totalCard)
        
        // BUTTONS
        let btnStack = UIStackView(arrangedSubviews: [chatButton, reserveButton])
        btnStack.axis = .vertical
        btnStack.spacing = 14
        content.addArrangedSubview(btnStack)
        
        chatButton.heightAnchor.constraint(equalToConstant: 48).isActive = true
        reserveButton.heightAnchor.constraint(equalToConstant: 48).isActive = true
        
        chatButton.addTarget(self, action: #selector(chatPressed), for: .touchUpInside)
        reserveButton.addTarget(self, action: #selector(reservePressed), for: .touchUpInside)
    }

    private func styleCard(_ card: UIStackView) {
        card.axis = .vertical
        card.spacing = 10
        card.backgroundColor = .white
        card.layer.cornerRadius = 16
        card.isLayoutMarginsRelativeArrangement = true
        card.layoutMargins = UIEdgeInsets(top: 14, left: 16, bottom: 14, right: 16)
    }

    private func line(_ label: UILabel) -> UIView {
        label.numberOfLines = 0
        let v = UIView()
        v.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: v.topAnchor),
            label.bottomAnchor.constraint(equalTo: v.bottomAnchor),
            label.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            label.trailingAnchor.constraint(equalTo: v.trailingAnchor)
        ])
        return v
    }

    private func padded(_ view: UIView) -> UIView {
        let container = UIView()
        container.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.topAnchor.constraint(equalTo: container.topAnchor, constant: 12),
            view.bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -12),
            view.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            view.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
        ])
        return container
    }

    private func sectionTitle(_ title: String) -> UILabel {
        let lbl = UILabel()
        lbl.font = .boldSystemFont(ofSize: 19)
        lbl.text = title
        return lbl
    }

    // MARK: - Travelers
    private func buildTravelerSection() {
        let adultRow = row(
            label: adultsLabel,
            stepper: adultsStepper,
            title: "Adultes",
            value: adults
        )
        
        let childRow = row(
            label: childrenLabel,
            stepper: childrenStepper,
            title: "Enfants",
            value: childrenCount
        )
        
        travelerCard.addArrangedSubview(adultRow)
        travelerCard.addArrangedSubview(childRow)
    }

    private func row(label: UILabel, stepper: UIStepper, title: String, value: Int) -> UIStackView {
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = .systemFont(ofSize: 16, weight: .medium)
        
        let valueLabel = label
        valueLabel.text = "\(value)"
        valueLabel.font = .systemFont(ofSize: 16)
        
        stepper.value = Double(value)
        stepper.minimumValue = (title == "Adultes" ? 1 : 0)
        stepper.addTarget(self, action: #selector(updateTravelers), for: .valueChanged)
        
        let row = UIStackView(arrangedSubviews: [titleLabel, valueLabel, stepper])
        row.axis = .horizontal
        row.distribution = .equalSpacing
        return row
    }

    @objc private func updateTravelers() {
        adults = Int(adultsStepper.value)
        childrenCount = Int(childrenStepper.value)
        
        adultsLabel.text = "\(adults)"
        childrenLabel.text = "\(childrenCount)"
        totalPriceLabel.text = "Total : \(totalPrice) DT"
    }

    // MARK: Fill data
    private func fillData() {
        titleLabel.text = offer.titre
        
        hotelLabel.text = "🏨 \(offer.hotelDisplayName) \(offer.hotelStarsText)"
        nightsLabel.text = "🛏 \(offer.nightsText)"
        mealLabel.text = "🍽 \(offer.mealTypeText)"
        dateLabel.text = "📅 \(offer.formattedStartDate) → \(offer.formattedEndDate)"
        transportLabel.text = offer.transportDisplay
        
        activitiesLabel.text = offer.activitiesListString
        placesLabel.text = offer.placesListString
        
        totalPriceLabel.text = "Total : \(totalPrice) DT"
        
        if let url = offer.firstImageURL {
            URLSession.shared.dataTask(with: url) { data, _, _ in
                if let data = data {
                    DispatchQueue.main.async { self.imageView.image = UIImage(data: data) }
                }
            }.resume()
        }
    }

    // MARK: Actions
    @objc private func chatPressed() {
        navigationController?.pushViewController(ChatViewController(offer: offer), animated: true)
    }

    @objc private func reservePressed() {
        let alert = UIAlertController(
            title: "Réservation envoyée 🎉",
            message: "Votre réservation pour \(adults) adulte(s) + \(childrenCount) enfant(s) a été envoyée.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
