import UIKit

class MainTabBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViewControllers()
        setupAppearance()
    }
    
    private func setupViewControllers() {
        
        // -------------------------------
        // 1️⃣ Écrans existants (ne pas toucher)
        // -------------------------------
        
        let homeVC = HomeViewController()
        homeVC.tabBarItem = UITabBarItem(
            title: "Accueil",
            image: UIImage(systemName: "house"),
            selectedImage: UIImage(systemName: "house.fill")
        )
        
        let insurancesVC = InsurancesViewController()
        insurancesVC.tabBarItem = UITabBarItem(
            title: "Assurances",
            image: UIImage(systemName: "shield"),
            selectedImage: UIImage(systemName: "shield.fill")
        )
        
        let offersVC = VoyageListViewController() // module ami
        offersVC.tabBarItem = UITabBarItem(
            title: "Offres",
            image: UIImage(systemName: "tag"),
            selectedImage: UIImage(systemName: "tag.fill")
        )
        
        let groupsVC = GroupsViewController()
        groupsVC.tabBarItem = UITabBarItem(
            title: "Groupes",
            image: UIImage(systemName: "person.3"),
            selectedImage: UIImage(systemName: "person.3.fill")
        )
        
        let profileVC = ProfileViewController()
        profileVC.tabBarItem = UITabBarItem(
            title: "Profil",
            image: UIImage(systemName: "person.circle"),
            selectedImage: UIImage(systemName: "person.circle.fill")
        )
        
        // -------------------------------
        // 2️⃣ TON MODULE Packs Voyages
        // -------------------------------
        
        let packsVC = PacksListViewController()
        packsVC.tabBarItem = UITabBarItem(
            title: "Packs",
            image: UIImage(systemName: "suitcase"),
            selectedImage: UIImage(systemName: "suitcase.fill")
        )
        
        // -------------------------------
        // 3️⃣ Navigation Controllers
        // -------------------------------
        
        let homeNav = UINavigationController(rootViewController: homeVC)
        let insurancesNav = UINavigationController(rootViewController: insurancesVC)
        let offersNav = UINavigationController(rootViewController: offersVC)
        let packsNav = UINavigationController(rootViewController: packsVC)
        let groupsNav = UINavigationController(rootViewController: groupsVC)
        let profileNav = UINavigationController(rootViewController: profileVC)
        
        
        // -------------------------------
        // 4️⃣ Setup Navigation Bars
        // -------------------------------
        
        [
            homeNav, insurancesNav, offersNav, packsNav, groupsNav, profileNav
        ].forEach { setupNavigationBarAppearance(for: $0) }
        
        
        // -------------------------------
        // 5️⃣ Ordre FINAL des onglets
        // -------------------------------
        
        viewControllers = [
            homeNav,
            offersNav,       // module ami – NE PAS TOUCHER
            packsNav,        // TON MODULE 🎒
            insurancesNav,
            groupsNav,
            profileNav
        ]
    }
    
    
    // MARK: - NavigationBar Style
    private func setupNavigationBarAppearance(for navController: UINavigationController) {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .white
        appearance.shadowColor = .clear
        
        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font: UIFont.systemFont(ofSize: 18, weight: .semibold)
        ]
        
        navController.navigationBar.standardAppearance = appearance
        navController.navigationBar.scrollEdgeAppearance = appearance
        
        navController.navigationBar.tintColor = .primaryColor
    }
    
    
    // MARK: - TabBar Style
    private func setupAppearance() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .white
        
        let itemAppearance = UITabBarItemAppearance()
        itemAppearance.normal.iconColor = .systemGray
        itemAppearance.selected.iconColor = .primaryColor
        itemAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.systemGray]
        itemAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor.primaryColor]
        
        appearance.stackedLayoutAppearance = itemAppearance
        
        tabBar.standardAppearance = appearance
        
        if #available(iOS 15.0, *) {
            tabBar.scrollEdgeAppearance = appearance
        }
    }
}
